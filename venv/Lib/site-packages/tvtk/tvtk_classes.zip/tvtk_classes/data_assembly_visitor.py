# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class DataAssemblyVisitor(Object):
    r"""
    DataAssemblyVisitor - visitor API for DataAssembly
    
    Superclass: Object
    
    DataAssemblyVisitor defines a visitor API for DataAssembly. A
    concrete subclass of DataAssemblyVisitor can be passed to
    `vtkdata_assembly::Visit` to execute custom code on each node in the
    data-assembly.
    
    `vtkdata_assembly::Visit` will call `vtkdata_assembly_visitor::Visit` on
    each node in the assembly (or chosen subtree). The traversal order,
    i.e. depth-first or breadth-first, is selected by the arguments
    passed to `vtkdata_assembly::Visit`. Before traversing a sub-tree for
    a particular node, `vtkdata_assembly_visitor::get_traverse_subtree` is
    called, if it returns false, the subtree is skipped. If it returns
    true, then then `vtkdata_assembly_visitor::begin_sub_tree` is called,
    followed by calls to `vtkdata_assembly_visitor::Visit` for each of the
    child nodes, and finally `vtkdata_assembly_visitor::end_sub_tree` is
    called.
    
    In depth-first order, the subtree traversal is recursive. Thus, after
    `begin_sub_tree` is called for specific node, all its children and
    their subtrees are traversed before `end_sub_tree` gets called for that
    node.
    
    In breadth-first order, a first-in-first-out queue is used. A node is
    visited, i.e. `vtkdata_assembly_visitor::Visit` called on it, then if
    `get_traverse_subtree` returns true, `Visit` gets called on all its
    immediate children one after another followed by `end_sub_tree` on the
    parent node. As each of the child nodes are visited, they get added
    to the queue. Now, for each node in the queue, the process repeats
    i.e. `get_traverse_subtree` is called, followed by the subtree
    traversal for that node. This continues until the queue empty.
    
    @sa DataAssembly
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkDataAssemblyVisitor, obj, update, **traits)
    
    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(DataAssemblyVisitor, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit DataAssemblyVisitor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit DataAssemblyVisitor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit DataAssemblyVisitor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

