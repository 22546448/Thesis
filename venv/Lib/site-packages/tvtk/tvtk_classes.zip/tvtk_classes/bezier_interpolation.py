# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.higher_order_interpolation import HigherOrderInterpolation


class BezierInterpolation(HigherOrderInterpolation):
    r"""
    BezierInterpolation
    
    Superclass: HigherOrderInterpolation
    
    See Also:
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkBezierInterpolation, obj, update, **traits)
    
    def de_casteljau_simplex(self, *args):
        """
        de_casteljau_simplex(dim:int, deg:int, pcoords:(float, ...),
            weights:[float, ...]) -> None
        C++: static void de_casteljau_simplex(const int dim, const int deg,
            const double *pcoords, double *weights)"""
        ret = self._wrap_call(self._vtk_obj.DeCasteljauSimplex, *args)
        return ret

    def de_casteljau_simplex_deriv(self, *args):
        """
        de_casteljau_simplex_deriv(dim:int, deg:int, pcoords:(float, ...),
            weights:[float, ...]) -> None
        C++: static void de_casteljau_simplex_deriv(const int dim,
            const int deg, const double *pcoords, double *weights)"""
        ret = self._wrap_call(self._vtk_obj.DeCasteljauSimplexDeriv, *args)
        return ret

    def evaluate_shape_and_gradient(self, *args):
        """
        evaluate_shape_and_gradient(order:int, pcoord:float, shape:[float,
            ...], grad:[float, ...]) -> None
        C++: static void evaluate_shape_and_gradient(int order,
            double pcoord, double *shape, double *grad)"""
        ret = self._wrap_call(self._vtk_obj.EvaluateShapeAndGradient, *args)
        return ret

    def evaluate_shape_functions(self, *args):
        """
        evaluate_shape_functions(order:int, pcoord:float, shape:[float,
            ...]) -> None
        C++: static void evaluate_shape_functions(int order, double pcoord,
            double *shape)"""
        ret = self._wrap_call(self._vtk_obj.EvaluateShapeFunctions, *args)
        return ret

    def flatten_simplex(self, *args):
        """
        flatten_simplex(dim:int, deg:int, coord:Vector3i) -> int
        C++: static int flatten_simplex(const int dim, const int deg,
            const Vector3i coord)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FlattenSimplex, *my_args)
        return ret

    def tensor1_shape_derivatives(self, *args):
        """
        tensor1_shape_derivatives(order:(int), pcoords:(float, ...),
            derivs:[float, ...]) -> int
        C++: static int tensor1_shape_derivatives(const int order[1],
            const double *pcoords, double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.Tensor1ShapeDerivatives, *args)
        return ret

    def tensor1_shape_functions(self, *args):
        """
        tensor1_shape_functions(order:(int), pcoords:(float, ...),
            shape:[float, ...]) -> int
        C++: static int tensor1_shape_functions(const int order[1],
            const double *pcoords, double *shape)"""
        ret = self._wrap_call(self._vtk_obj.Tensor1ShapeFunctions, *args)
        return ret

    def tensor2_shape_derivatives(self, *args):
        """
        tensor2_shape_derivatives(order:(int, int), pcoords:(float, ...),
            derivs:[float, ...]) -> int
        C++: static int tensor2_shape_derivatives(const int order[2],
            const double *pcoords, double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.Tensor2ShapeDerivatives, *args)
        return ret

    def tensor2_shape_functions(self, *args):
        """
        tensor2_shape_functions(order:(int, int), pcoords:(float, ...),
            shape:[float, ...]) -> int
        C++: static int tensor2_shape_functions(const int order[2],
            const double *pcoords, double *shape)"""
        ret = self._wrap_call(self._vtk_obj.Tensor2ShapeFunctions, *args)
        return ret

    def tensor3_shape_derivatives(self, *args):
        """
        tensor3_shape_derivatives(order:(int, int, int), pcoords:(float,
            ...), derivs:[float, ...]) -> int
        C++: static int tensor3_shape_derivatives(const int order[3],
            const double *pcoords, double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.Tensor3ShapeDerivatives, *args)
        return ret

    def tensor3_shape_functions(self, *args):
        """
        tensor3_shape_functions(order:(int, int, int), pcoords:(float, ...),
             shape:[float, ...]) -> int
        C++: static int tensor3_shape_functions(const int order[3],
            const double *pcoords, double *shape)"""
        ret = self._wrap_call(self._vtk_obj.Tensor3ShapeFunctions, *args)
        return ret

    def un_flatten_simplex(self, *args):
        """
        un_flatten_simplex(dim:int, deg:int, flat:int) -> Vector3i
        C++: static Vector3i un_flatten_simplex(const int dim,
            const int deg, const IdType flat)"""
        ret = self._wrap_call(self._vtk_obj.UnFlattenSimplex, *args)
        return wrap_vtk(ret)

    def wedge_shape_derivatives(self, *args):
        """
        wedge_shape_derivatives(order:(int, int, int), numberOfPoints:int,
            pcoords:(float, ...), derivs:[float, ...]) -> None
        C++: static void wedge_shape_derivatives(const int order[3],
            const IdType numberOfPoints, const double *pcoords,
            double *derivs)"""
        ret = self._wrap_call(self._vtk_obj.WedgeShapeDerivatives, *args)
        return ret

    def wedge_shape_functions(self, *args):
        """
        wedge_shape_functions(order:(int, int, int), numberOfPoints:int,
            pcoords:(float, ...), shape:[float, ...]) -> None
        C++: static void wedge_shape_functions(const int order[3],
            const IdType numberOfPoints, const double *pcoords,
            double *shape)"""
        ret = self._wrap_call(self._vtk_obj.WedgeShapeFunctions, *args)
        return ret

    def de_casteljau_simplex(self, *args):
        """
        de_casteljau_simplex(dim:int, deg:int, pcoords:(float, ...),
            weights:[float, ...]) -> None
        C++: static void de_casteljau_simplex(const int dim, const int deg,
            const double *pcoords, double *weights)"""
        ret = self._wrap_call(self._vtk_obj.deCasteljauSimplex, *args)
        return ret

    def de_casteljau_simplex_deriv(self, *args):
        """
        de_casteljau_simplex_deriv(dim:int, deg:int, pcoords:(float, ...),
            weights:[float, ...]) -> None
        C++: static void de_casteljau_simplex_deriv(const int dim,
            const int deg, const double *pcoords, double *weights)"""
        ret = self._wrap_call(self._vtk_obj.deCasteljauSimplexDeriv, *args)
        return ret

    def flatten_simplex(self, *args):
        """
        flatten_simplex(dim:int, deg:int, coord:Vector3i) -> int
        C++: static int flatten_simplex(const int dim, const int deg,
            const Vector3i coord)"""
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.flattenSimplex, *my_args)
        return ret

    def unflatten_simplex(self, *args):
        """
        unflatten_simplex(dim:int, deg:int, flat:int) -> Vector3i
        C++: static Vector3i unflatten_simplex(const int dim,
            const int deg, const IdType flat)"""
        ret = self._wrap_call(self._vtk_obj.unflattenSimplex, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(BezierInterpolation, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit BezierInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit BezierInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit BezierInterpolation properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

