# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.parallel_render_manager import ParallelRenderManager


class CompositeRenderManager(ParallelRenderManager):
    r"""
    CompositeRenderManager - An object to control sort-last parallel
    rendering.
    
    Superclass: ParallelRenderManager
    
    CompositeRenderManager is a subclass of ParallelRenderManager
    that uses compositing to do parallel rendering.  This class has
    replaced CompositeManager.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkCompositeRenderManager, obj, update, **traits)
    
    def _get_compositer(self):
        return wrap_vtk(self._vtk_obj.GetCompositer())
    def _set_compositer(self, arg):
        old_val = self._get_compositer()
        self._wrap_call(self._vtk_obj.SetCompositer,
                        deref_vtk(arg))
        self.trait_property_changed('compositer', old_val, arg)
    compositer = traits.Property(_get_compositer, _set_compositer, desc=\
        r"""
        
        """
    )

    _updateable_traits_ = \
    (('auto_image_reduction_factor', 'GetAutoImageReductionFactor'),
    ('magnify_images', 'GetMagnifyImages'), ('parallel_rendering',
    'GetParallelRendering'), ('render_event_propagation',
    'GetRenderEventPropagation'), ('sync_render_window_renderers',
    'GetSyncRenderWindowRenderers'), ('synchronize_tile_properties',
    'GetSynchronizeTileProperties'), ('use_back_buffer',
    'GetUseBackBuffer'), ('use_compositing', 'GetUseCompositing'),
    ('write_back_images', 'GetWriteBackImages'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('magnify_image_method', 'GetMagnifyImageMethod'),
    ('default_render_event_propagation',
    'GetDefaultRenderEventPropagation'), ('force_render_window_size',
    'GetForceRenderWindowSize'), ('forced_render_window_size',
    'GetForcedRenderWindowSize'), ('image_reduction_factor',
    'GetImageReductionFactor'), ('max_image_reduction_factor',
    'GetMaxImageReductionFactor'), ('use_rgba', 'GetUseRGBA'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['auto_image_reduction_factor', 'debug', 'global_warning_display',
    'magnify_images', 'parallel_rendering', 'render_event_propagation',
    'sync_render_window_renderers', 'synchronize_tile_properties',
    'use_back_buffer', 'use_compositing', 'write_back_images',
    'magnify_image_method', 'default_render_event_propagation',
    'force_render_window_size', 'forced_render_window_size',
    'image_reduction_factor', 'max_image_reduction_factor', 'object_name',
    'use_rgba'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(CompositeRenderManager, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit CompositeRenderManager properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['auto_image_reduction_factor', 'magnify_images',
            'parallel_rendering', 'render_event_propagation',
            'sync_render_window_renderers', 'synchronize_tile_properties',
            'use_back_buffer', 'use_compositing', 'write_back_images'],
            ['magnify_image_method'], ['default_render_event_propagation',
            'force_render_window_size', 'forced_render_window_size',
            'image_reduction_factor', 'max_image_reduction_factor', 'object_name',
            'use_rgba']),
            title='Edit CompositeRenderManager properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit CompositeRenderManager properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

